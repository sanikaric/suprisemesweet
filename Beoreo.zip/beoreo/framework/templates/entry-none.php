<div class="no-results">
	<h1 class="page-title"><?php _e( 'Nothing Found', 'beoreo' ); ?></h1>
	<p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'beoreo' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
</div>