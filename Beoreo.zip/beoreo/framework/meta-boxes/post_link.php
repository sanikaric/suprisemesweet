<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->text('post_link',
			'Link URL',
			'',
			__('Please input the URL for your link. http://www.youwebsite.com','beoreo')
	);
	?>
</div>
