<div id="tb_team_metabox" class='tb-team-metabox'>
	<?php
	$this->text('team_position',
			'Position',
			'',
			__('Enter team position of post. EX: Business Analysis','beoreo')
	);
	$this->text('team_work_time',
			'Work Time',
			'',
			__('Enter team work time of post. EX: 9am - 5pm','beoreo')
	);
	$this->text('team_percent',
			'Percent',
			'',
			__('Enter team percent of post. EX: 48%','beoreo')
	);
	$this->text('team_facebook',
			'Facebook',
			'',
			__('Enter link facebook of post.','beoreo')
	);
	$this->text('team_twitter',
			'Twitter',
			'',
			__('Enter link twitter of post.','beoreo')
	);
	$this->text('team_linkedin',
			'Linkedin',
			'',
			__('Enter link linkedin of post.','beoreo')
	);
	$this->text('team_pinterest',
			'Pinterest',
			'',
			__('Enter link pinterest of post.','beoreo')
	);
	$this->text('team_google_plus',
			'Google Plus',
			'',
			__('Enter link google plus of post.','beoreo')
	);
	$this->text('team_tumblr',
			'Tumblr',
			'',
			__('Enter link tumblr of post.','beoreo')
	);
	$this->text('team_instagram',
			'Instagram',
			'',
			__('Enter link instagram of post.','beoreo')
	);
	$this->text('team_flickr',
			'Flickr',
			'',
			__('Enter link flickr of post.','beoreo')
	);
	?>
</div>
