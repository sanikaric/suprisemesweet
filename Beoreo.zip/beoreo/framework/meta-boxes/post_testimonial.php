<div id="tb_testimonial_metabox" class='tb-testimonial-metabox'>
	<?php
	$this->text('testimonial_position',
			'Position',
			'',
			__('Enter testimonial position of post. EX: Business Analysis','beoreo')
	);
	
	?>
</div>
