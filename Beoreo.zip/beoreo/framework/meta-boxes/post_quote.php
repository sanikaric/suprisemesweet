<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->textarea('post_quote',
			'Content',
			__('Please type the text for your quote here.','beoreo')
	);
	?>
</div>
